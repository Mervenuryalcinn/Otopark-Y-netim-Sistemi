package controllers;
import controllers.Observer;



public interface Observer {
    void update(String name, String email, String parkArea);
}
